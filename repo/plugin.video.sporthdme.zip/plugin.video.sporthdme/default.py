# -*- coding: utf-8 -*-
from __future__ import print_function
import xbmcvfs
import base64
import re
import sys
import six
from six.moves.urllib.parse import urljoin, quote_plus, quote, unquote, parse_qsl, urlencode, urlparse
from datetime import datetime, timedelta
import json
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import requests
from resources.modules import control, client
from resources.modules import resolver
import time
from dateutil.parser import parse
from dateutil.tz import gettz
from dateutil import parser, tz
from resources.scrapers import futbollibre, footie, highhub
_url = sys.argv[0]
_handle = int(sys.argv[1])

ADDON = xbmcaddon.Addon()
ADDON_DATA = ADDON.getAddonInfo('profile')
ADDON_PATH = ADDON.getAddonInfo('path')
DESCRIPTION = ADDON.getAddonInfo('description')
FANART = ADDON.getAddonInfo('fanart')
ICON = ADDON.getAddonInfo('icon')
ID = ADDON.getAddonInfo('id')
NAME = ADDON.getAddonInfo('name')
VERSION = ADDON.getAddonInfo('version')
Lang = ADDON.getLocalizedString
Dialog = xbmcgui.Dialog()
vers = VERSION
ART = ADDON_PATH + "/resources/icons/"

BASEURL = 'https://one.sporthd.me/'  # 'https://sporthd.live/'  #'https://sportl.ivesoccer.sx/'
Live_url = 'https://super.league.do'  #'https://one.sporthd.me/'  # 'https://sportl.ivesoccer.sx/'
Alt_url = 'https://futbollibre.ws/'  # 'https://1.livesoccer.sx/program'
headers = {'User-Agent': client.agent(),
           'Referer': BASEURL}


def Main_menu():
    # addDir('[B][COLOR gold]Channels 24/7[/COLOR][/B]', 'https://1.livesoccer.sx/program.php', 14, ICON, FANART, '')
    addDir('[B][COLOR gold]ALL EVENTS[/COLOR][/B]', 'all', 'all_events', ICON, FANART, True)
    addDir('[B][COLOR white]LIVE EVENTS[/COLOR][/B]', Live_url, 'events', ICON, FANART, True)
    # addDir('[B][COLOR gold]Alternative VIEW [/COLOR][/B]', '', '', ICON, FANART, '')
    addDir('[B][COLOR gold]FutbolLibre LIVE EVENTS[/COLOR][/B]', 'futbollibre', 'futbollibre_events', ICON, FANART, True)
    addDir('[B][COLOR gold]Footie EVENTS[/COLOR][/B]', 'today', 'footie_events', ICON, FANART, True)
    addDir('[B][COLOR gold]Footie HIGHLIGHTS[/COLOR][/B]', 'today', 'footie_highlights', ICON, FANART, True)
    # addDir('[B][COLOR white]SPORTS[/COLOR][/B]', '', 3, ICON, FANART, '')
    # addDir('[B][COLOR white]BEST LEAGUES[/COLOR][/B]', '', 2, ICON, FANART, '')
    addDir('[B][COLOR gold]Settings[/COLOR][/B]', 'set', 'settings', ICON, FANART, False)
    addDir('[B][COLOR gold]Clear Addon Data[/COLOR][/B]', 'clear', 'clear', ICON, FANART, False)
    addDir('[B][COLOR gold]Version: [COLOR lime]{}[/COLOR][/B]'.format(vers), '', 'version', ICON, FANART, False)
    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)


def _fmt_local_time(dt_local):
    try:
        time_fmt = xbmc.getRegion('time').replace(':%S', '')
    except Exception:
        time_fmt = "%H:%M"
    return dt_local.strftime(time_fmt)


def _epoch_to_local_dt(epoch_seconds):
    try:
        local_tz = fetch_user_timezone()
        if six.PY2:
            return datetime.fromtimestamp(int(epoch_seconds), tz=local_tz)
        return datetime.fromtimestamp(int(epoch_seconds), tz=local_tz)
    except Exception:
        return None


def _platform_open_url(url):
    """
    Best-effort: open a URL in the OS default browser.
    Falls back to showing the URL in a dialog.
    """
    try:
        u = six.ensure_text(url, encoding='utf-8', errors='ignore')
        if not u:
            return
        if xbmc.getCondVisibility('system.platform.osx'):
            xbmc.executebuiltin('System.Exec(open "%s")' % u)
            return
        if xbmc.getCondVisibility('system.platform.windows'):
            xbmc.executebuiltin('System.Exec(cmd /c start "" "%s")' % u)
            return
        # linux / others
        xbmc.executebuiltin('System.Exec(xdg-open "%s")' % u)
    except Exception:
        try:
            Dialog.ok(NAME, url)
        except Exception:
            pass


def show_footie_events():
    # Use match page sttime for exact local start time, and sort by time (not by site category).
    events = footie.list_events_with_times()
    if not events:
        addDir("[COLOR red]No events found.[/COLOR]", '', '', ICON, '')
        xbmcplugin.endOfDirectory(_handle)
        return

    local_tz = fetch_user_timezone()
    for ev in events:
        team1 = ev.get('team1', '')
        team2 = ev.get('team2', '')
        league = ev.get('league', '')

        sttime = ev.get('sttime')
        start_dt = _epoch_to_local_dt(sttime) if sttime else None

        # Always show the start time; color indicates live/not live.
        if start_dt:
            time_label = _fmt_local_time(start_dt)
        else:
            time_label = '--:--'

        m_color = "lime" if ev.get('is_live') else "gold"

        time_part = u'[COLOR cyan]{0}[/COLOR]'.format(time_label)
        title_part = u'[COLOR {0}]{1} vs {2}[/COLOR]'.format(m_color, team1, team2)
        league_part = u' - [I]{0}[/I]'.format(league) if league else ''
        label = u'{0} {1}{2} - [I]footie[/I]'.format(time_part, title_part, league_part)

        match_url = ev.get('match_url', '')
        icon = ev.get('league_icon') or ICON
        addDir(label, match_url, 'footie_streams', icon, '')

    xbmcplugin.setContent(_handle, 'videos')
    xbmcplugin.endOfDirectory(_handle)


def show_footie_streams(match_url):
    info = footie.get_match_streams(match_url)
    title = info.get('title') or ''
    league = info.get('league') or ''
    sttime = info.get('sttime')

    start_dt = _epoch_to_local_dt(sttime) if sttime else None
    time_label = _fmt_local_time(start_dt) if start_dt else ''
    event_title = u'[{0}] {1} - {2}'.format(time_label, title, league).strip(' -')

    for st in info.get('streams', []):
        nm = st.get('name') or 'stream'
        url_ = st.get('url') or ''
        # Pack url + referer into payload so resolver can use it
        payload = json.dumps({'u': url_, 'r': match_url})
        enc = quote(base64.b64encode(six.ensure_binary(payload)))
        addDir(nm, enc, 'footie_play', ICON, event_title, isFolder=False)

    xbmcplugin.setContent(_handle, 'videos')
    xbmcplugin.endOfDirectory(_handle)


def footie_play(encoded_payload, title=''):
    try:
        raw = base64.b64decode(unquote(encoded_payload))
        data = json.loads(six.ensure_text(raw, encoding='utf-8', errors='ignore'))
        url_ = data.get('u', '')
        ref = data.get('r', '')
    except Exception:
        url_, ref = encoded_payload, ''

    final_url = resolve2(url_, referer=ref or None)
    xbmc.log('footie_play: %s' % final_url)

    event_title = six.ensure_text(title, encoding='utf-8', errors='ignore') if title is not None else u''
    try:
        liz = xbmcgui.ListItem(label=event_title or NAME, path=final_url)
    except TypeError:
        liz = xbmcgui.ListItem(event_title or NAME)
        liz.setPath(final_url)
    liz.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': FANART})
    liz.setProperty('IsPlayable', 'true')
    liz.setPath(final_url)

    try:
        tag = liz.getVideoInfoTag()
        if event_title:
            tag.setTitle(event_title)
    except Exception:
        pass

    try:
        xbmcplugin.setResolvedUrl(_handle, True, liz)
    except Exception:
        xbmc.Player().play(final_url, liz, False)


def show_footie_highlights():
    # Highlights source: watchfootballhighlights.com
    items = highhub.list_highlights()
    if not items:
        addDir("[COLOR red]No highlights found.[/COLOR]", '', '', ICON, '')
        xbmcplugin.endOfDirectory(_handle)
        return

    for it in items:
        title = it.get('title', '')
        url_ = it.get('url', '')
        img = it.get('icon', '') or ICON
        league = it.get('league', '')
        when = it.get('time', '')
        # Keep it compact: show time and league (optional)
        extra = u''
        if when:
            extra += u' [COLOR cyan]{0}[/COLOR]'.format(when)
        if league:
            extra += u' - [I]{0}[/I]'.format(league)
        label = u'{0}{1} - [I]highlights[/I]'.format(title, extra)
        addDir(label, url_, 'footie_open', img, '', isFolder=False)

    xbmcplugin.endOfDirectory(_handle)


def get_events(url):  # 5
    # data = client.request(url)
    data = requests.get(url)
    data = data.text
    data = six.ensure_text(data, encoding='utf-8', errors='ignore')
    data = re.sub('\t', '', data).replace('&nbsp', '')

    events = client.parseDOM(data, 'script')
    try:
        events = [i for i in events if '''matchDate''' in i][0]
    except:
        control.infoDialog("[COLOR red]No Match Scheduled.[/COLOR]", NAME, ICON, 5000)
        return

    new_pattern = r'window\.matches\s*=\s*JSON\.parse\(`(\[.+?\])`\)'

    new_matches = re.findall(new_pattern, events, re.DOTALL)

    if new_matches:
        matches_json = new_matches[0]
        matches = json.loads(matches_json)
    else:
        events = events[:-1].replace('self.__next_f.push(', '').replace('\\', '')
        old_pattern = r'"matches"\s*\:\s*(\[.+?])}]]}]n'
        old_matches = re.findall(old_pattern, events.replace(',false', ''), re.DOTALL)[0]
        if old_matches:
            matches = json.loads(old_matches)
        else:
            control.infoDialog("[COLOR red]No matches data found.[/COLOR]", NAME, ICON, 5000)
            return

    # matches = re.findall('''null\,(\{"(?:matches|customNotFoundMessage).+?)\]\}\]n''', events, re.DOTALL)[0]
    # pattern = r'("matches"\s*\:\s*\[.+?])}]}]n"'
    #pattern = r'"matches"\s*\:\s*(\[.+?])}]]}]n'
    #matches = re.findall(pattern, events.replace(',false', ''), re.DOTALL)[0]
    # xbmc.log('EVENTSSS: {}'.format(matches))
    #matches = json.loads(matches)

    event_list = []

    if six.PY2:
        now = datetime.now()
        now_time_in_ms = (time.mktime(now.timetuple()) + now.microsecond / 1e6) * 1000
    else:
        now_time_in_ms = datetime.now().timestamp() * 1000
    for match in matches:
        channels = match.get("channels", [])
        # links = match['additionalLinks']
        # links.extend(match['channels'])
        icon = match.get('team1Img', ICON)
        sport = match.get('sport', '')
        lname = match.get('league', None)
        lname = six.ensure_text(lname, encoding='utf-8', errors='replace') if lname else sport
        team1 = match.get('team1', None)
        team1 = six.ensure_text(team1, encoding='utf-8', errors='replace') if team1 else None
        team2 = match.get('team2', None)
        team2 = six.ensure_text(team2, encoding='utf-8', errors='replace') if team2 else None
        event = u"{} vs {}".format(team1, team2) if team1 and team2 else team1

        try:
            compare = match['startTimestamp']
            ftime = time_convert(compare)
        except:
            try:
                matchdt = match['matchDate']
                tvtime = match['livetvtimestr']
                compare = adjust_date_and_convert_to_timestamp_ms(matchdt, tvtime)
                ftime = time_convert(compare)
                # xbmc.log('SHOW FTIME: {}'.format(ftime))
            except:
                compare = int('999999999999')
                ftime = '-'

        duration_in_ms = match['duration'] * 60 * 1000

        is_live = False
        if compare <= now_time_in_ms <= compare + duration_in_ms:
            is_live = True

        m_color = "lime" if is_live else "gold"
        ftime = '[COLOR cyan]{}[/COLOR]'.format(ftime)
        name = u'{0} [COLOR {1}]{2}[/COLOR] - [I]{3}[/I]'.format(ftime, m_color, event, lname)
        event_list.append([name, compare, channels, icon])

        # streams = str(quote(base64.b64encode(six.ensure_binary(str(streams)))))
    events = sorted(event_list, key=lambda x: x[1])
    for event in deduplicate_events(events):
        streams = str(quote(base64.b64encode(six.ensure_binary(str(event[2])))))
        name = event[0]
        icon = event[3]
        addDir(name, streams, 'get_streams', icon, FANART, isFolder=True)

    xbmcplugin.setContent(_handle, 'videos')
    xbmcplugin.endOfDirectory(_handle)


def sporthd_list_events(url):
    """
    Return SportHD events as a list (without rendering).
    Each entry contains:
      - label: already color-formatted label (time cyan, match lime/gold, league italic)
      - compare: start timestamp in ms (for sorting)
      - streams: encoded streams payload (string for get_streams mode)
      - icon: thumbnail/icon
    """
    data = requests.get(url)
    data = data.text
    data = six.ensure_text(data, encoding='utf-8', errors='ignore')
    data = re.sub('\t', '', data).replace('&nbsp', '')

    events = client.parseDOM(data, 'script')
    try:
        events = [i for i in events if '''matchDate''' in i][0]
    except Exception:
        return []

    new_pattern = r'window\.matches\s*=\s*JSON\.parse\(`(\[.+?\])`\)'
    new_matches = re.findall(new_pattern, events, re.DOTALL)

    if new_matches:
        matches_json = new_matches[0]
        matches = json.loads(matches_json)
    else:
        events = events[:-1].replace('self.__next_f.push(', '').replace('\\', '')
        old_pattern = r'"matches"\s*\:\s*(\[.+?])}]]}]n'
        old_matches = re.findall(old_pattern, events.replace(',false', ''), re.DOTALL)
        if old_matches:
            matches = json.loads(old_matches[0])
        else:
            return []

    out = []

    if six.PY2:
        now = datetime.now()
        now_time_in_ms = (time.mktime(now.timetuple()) + now.microsecond / 1e6) * 1000
    else:
        now_time_in_ms = datetime.now().timestamp() * 1000

    event_list = []
    for match in matches:
        channels = match.get("channels", [])
        icon = match.get('team1Img', ICON)
        sport = match.get('sport', '')
        lname = match.get('league', None)
        lname = six.ensure_text(lname, encoding='utf-8', errors='replace') if lname else sport
        team1 = match.get('team1', None)
        team1 = six.ensure_text(team1, encoding='utf-8', errors='replace') if team1 else None
        team2 = match.get('team2', None)
        team2 = six.ensure_text(team2, encoding='utf-8', errors='replace') if team2 else None
        event = u"{} vs {}".format(team1, team2) if team1 and team2 else team1

        try:
            compare = match['startTimestamp']
            ftime = time_convert(compare)
        except Exception:
            try:
                matchdt = match['matchDate']
                tvtime = match['livetvtimestr']
                compare = adjust_date_and_convert_to_timestamp_ms(matchdt, tvtime)
                ftime = time_convert(compare)
            except Exception:
                compare = int('999999999999')
                ftime = '-'

        duration_in_ms = match.get('duration', 0) * 60 * 1000
        is_live = False
        if duration_in_ms and compare <= now_time_in_ms <= compare + duration_in_ms:
            is_live = True

        m_color = "lime" if is_live else "gold"
        ftime = '[COLOR cyan]{}[/COLOR]'.format(ftime)
        label = u'{0} [COLOR {1}]{2}[/COLOR] - [I]{3}[/I] - [I]sporthd[/I]'.format(ftime, m_color, event, lname)
        event_list.append([label, compare, channels, icon])

    events_sorted = sorted(deduplicate_events(event_list), key=lambda x: x[1])
    for label, compare, channels, icon in events_sorted:
        streams = str(quote(base64.b64encode(six.ensure_binary(str(channels)))))
        out.append({'label': label, 'compare': compare, 'streams': streams, 'icon': icon})

    return out


def show_all_events():
    """
    Combined (append-only) events list from SportHD + Pelota, sorted by start time.
    No merge/dedupe between providers; we only add extra events and sort by time.
    """
    # Keep existing SportHD channel-data refresh behavior
    try:
        if time_to_update():
            fetch_and_store_channel_data()
            update_last_update_time()
    except Exception:
        pass

    combined = []

    # SportHD
    try:
        for ev in sporthd_list_events(Live_url):
            combined.append({
                'ts': int(ev.get('compare') or 999999999999),
                'mode': 'get_streams',
                'url': ev.get('streams', ''),
                'name': ev.get('label', ''),
                'icon': ev.get('icon', ICON),
                'desc': FANART,  # not used by get_streams; keep arg shape
                'isFolder': True
            })
    except Exception:
        pass

    # FutbolLibre
    try:
        for ev in futbollibre.list_events():
            date_ = ev.get('date')
            start_local = pelota_event_dt_local(ev.get('time', ''), date_)
            if start_local:
                if six.PY2:
                    ts = int((time.mktime(start_local.timetuple()) + start_local.microsecond / 1e6) * 1000)
                else:
                    ts = int(start_local.timestamp() * 1000)
            else:
                ts = 999999999999

            # Live coloring: lime if live now (within window), otherwise gold
            m_color = "gold"
            if start_local:
                live_window_minutes = 240
                now_local = datetime.now(start_local.tzinfo)
                if start_local <= now_local <= (start_local + timedelta(minutes=live_window_minutes)):
                    m_color = "lime"

            local_time = pelota_time_to_local(ev.get('time', ''), date_)
            time_part = u'[COLOR cyan]{0}[/COLOR]'.format(local_time)
            title_part = u'[COLOR {0}]{1}[/COLOR]'.format(m_color, ev.get('title', ''))
            league = ev.get('league', '')
            league_part = (u' - [I]{0}[/I]'.format(league)) if league else u''
            label = u'{0} {1}{2} - [I]futbollibre[/I]'.format(time_part, title_part, league_part)

            icon = ev.get('icon') or ICON
            combined.append({
                'ts': ts,
                'mode': 'futbollibre_streams',
                'url': str(ev.get('id', '')),
                'name': label,
                'icon': icon,
                'desc': '',
                'isFolder': True
            })
    except Exception:
        pass

    combined = sorted(combined, key=lambda x: x.get('ts', 999999999999))
    for item in combined:
        addDir(item['name'], item['url'], item['mode'], item['icon'], item.get('desc', ''), isFolder=item.get('isFolder', True))

    xbmcplugin.setContent(_handle, 'videos')
    xbmcplugin.endOfDirectory(_handle)


def deduplicate_events(events):
    unique_events = []
    for event in events:
        unique_key = (event[0], event[1], tuple(event[2]), event[3])
        if unique_key not in unique_events:
            unique_events.append(unique_key)
    return unique_events


def show_futbollibre_events():
    events = futbollibre.list_events()
    if len(events) > 0:
        for ev in events:
            date_ = ev.get('date')
            local_time = pelota_time_to_local(ev.get('time', ''), date_)  # reusing helper (source tz is handled inside)

            # Live coloring: lime if live now (within window), otherwise gold
            start_local = pelota_event_dt_local(ev.get('time', ''), date_)
            m_color = "gold"
            if start_local:
                live_window_minutes = 240
                now_local = datetime.now(start_local.tzinfo)
                if start_local <= now_local <= (start_local + timedelta(minutes=live_window_minutes)):
                    m_color = "lime"

            time_part = u'[COLOR cyan]{0}[/COLOR]'.format(local_time)
            title_part = u'[COLOR {0}]{1}[/COLOR]'.format(m_color, ev.get('title', ''))
            league = ev.get('league', '')
            league_part = (u' - [I]{0}[/I]'.format(league)) if league else u''
            label = u'{0} {1}{2} - [I]futbollibre[/I]'.format(time_part, title_part, league_part)

            icon = ev.get('icon') or ICON
            addDir(label, str(ev.get('id', '')), 'futbollibre_streams', icon, '')
    else:
        addDir("[COLOR red]No Match Scheduled.[/COLOR]", '', '', ICON, '')
    xbmcplugin.endOfDirectory(_handle)



def show_futbollibre_streams(event_id):
    streams = futbollibre.get_streams(event_id)
    # Find event for nice title (best-effort)
    ev_title = ''
    ev_time = ''
    ev_date = None
    try:
        eid = int(event_id)
        for ev in futbollibre.list_events():
            if ev.get('id') == eid:
                ev_title = ev.get('title', '')
                ev_time = ev.get('time', '')
                ev_date = ev.get('date')
                break
    except Exception:
        pass

    local_time = pelota_time_to_local(ev_time, ev_date)
    event_title = u'[{0}] {1}'.format(local_time, ev_title).strip()

    for st in streams or []:
        name = st.get('nombre') or st.get('name') or 'Stream'
        quality = st.get('calidad') or st.get('quality') or ''
        label = name
        if quality:
            label = u'%s [%s]' % (label, quality)
        url_ = st.get('url') or st.get('href') or ''
        addDir(label, url_, 'futbollibre_play', ICON, event_title, isFolder=False)

    xbmcplugin.endOfDirectory(_handle)


def futbollibre_play(url, title=''):
    final_url = futbollibre.resolve(url)
    xbmc.log('futbollibre_play: %s' % final_url)
   
    event_title = six.ensure_text(title, encoding='utf-8', errors='ignore') if title is not None else u''

    try:
        liz = xbmcgui.ListItem(label=event_title or NAME, path=final_url)
    except TypeError:
        liz = xbmcgui.ListItem(event_title or NAME)
        liz.setPath(final_url)
    liz.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': FANART})
    liz.setProperty('IsPlayable', 'true')
    liz.setPath(final_url)

    # Prefer modern InfoTagVideo API (avoids setInfo deprecation warnings)
    if event_title:
        try:
            tag = liz.getVideoInfoTag()
            tag.setTitle(event_title)
        except Exception:
            try:
                liz.setInfo('video', {'title': event_title})
            except TypeError:
                liz.setInfo(type="Video", infoLabels={'title': event_title})

    # Preferred Kodi way: resolve the URL for the selected ListItem
    try:
        xbmc.log('futbollibre_play: using xbmcplugin.setResolvedUrl', xbmc.LOGINFO)
        xbmcplugin.setResolvedUrl(_handle, True, liz)
    except Exception as e:
        xbmc.log('futbollibre_play: setResolvedUrl failed, falling back to xbmc.Player().play(): %s' % e, xbmc.LOGWARNING)
        xbmc.Player().play(final_url, liz, False)



def get_stream(name, url):  # 4
    data = six.ensure_text(base64.b64decode(unquote(url))).strip('\n')

    import ast
    sstreams = []
    for event in ast.literal_eval(data):
        if not isinstance(event, dict):  # TNT Sports 1
            datos = get_links_for_channel(event)
            # xbmc.log('SHOW DATOS: {}'.format(datos))
            for chan, link, lang in datos:
                chan = '[COLOR gold]{}[/COLOR] - {}'.format(chan, lang)
                sstreams.append((link, chan))

        else:
            link = event.get('links', [])
            lang = event.get('language', '')
            chan = six.ensure_text(event.get('name', ''), encoding='utf-8', errors='replace')
            chan = '[COLOR gold]{}[/COLOR] - {}'.format(chan, lang)
            for url_ in link:
                sstreams.append((url_, chan))

    if len(sstreams) < 1:
        control.infoDialog("[COLOR gold]No Links available ATM.\n [COLOR lime]Try Again Later![/COLOR]", NAME,
                           ICON, 5000)
        return
    else:
        if len(sstreams) > 1:
            for i in sstreams:
                title, link = i[1], i[0]
                if not 'vecdn' in link:
                    # if not 'https://bedsport' in link and not 'vecdn' in link:
                    if not str(link) == str(title):
                        title += ' | {}'.format(urlparse(link).netloc)
                info = {'title': title, 'sorttitle': '', 'plot': name}
                addDir(title, link, 'play_stream', ICON, name, isFolder=False, infoLabels=info)
            xbmcplugin.setContent(_handle, 'videos')
            xbmcplugin.endOfDirectory(_handle)

        else:
            link = sstreams[0][0]
            resolve2(name, link)


def xbmc_curl_encode(url, headers):
    return "{}|{}".format(url, urlencode(headers))


def resolve2(name, url):
    stream_url = ''
    ua_win = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36'
    ua = 'Mozilla/5.0 (iPad; CPU OS 15_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6.1 Mobile/15E148 Safari/604.1'
    
    resolved = ['//virazon', '//dabac', '//sansat', '//istorm', '//zvision', '//glisco', '//bedsport', '//coolrea', '//evfancy', '//s2watch', '//vuen', '//gopst']
    #new_streams = ['//dabac']
    xbmc.log('RESOLVE-URL: {}'.format(url))
    if any(i in url for i in resolved):
        Dialog.notification(NAME, "[COLOR skyblue]Attempting To Resolve Link Now[/COLOR]", ICON, 2000, False)
        referer = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(url))
        r = six.ensure_str(client.request(url))
        if 'get_content.php?channel=' in r or 'api/player.php?id=' in r:
            id_ = re.findall(r'(\d+)$', url)[0]
            if 'get_content.php?channel=' in r:
                frame = referer+"get_content.php"
                hdr = {
                        'referer': url,
                        # 'sec-fetch-mode': 'cors',
                        'user-agent': ua_win,
                    }
                params = {'channel': id_,}
            elif 'api/player.php?id=' in r:
                frame = referer+"api/player.php"
                hdr = {
                        'referer': url,
                        # 'sec-fetch-mode': 'cors',
                        'user-agent': ua_win,
                    }
                params = {'id': id_,}
            r = six.ensure_str(requests.get(frame, params=params, headers=hdr).content)
        if 'fid=' in r:
            regex = '''<script>fid=['"](.+?)['"].+?text/javascript.*?src=['"](.+?)['"]></script>'''
            vid, getembed = re.findall(regex, r, re.DOTALL)[0]
            getembed = 'https:' + getembed if getembed.startswith('//') else getembed
            embed = six.ensure_str(client.request(getembed))
            embed = re.findall(r'''document.write.+?src=['"](.+?player)=''', embed, re.DOTALL)[0]
            host = '{}=desktop&live={}'.format(embed, str(vid))
            data = six.ensure_str(client.request(host, referer=referer))
            try:
                link = re.findall(r'''return\((\[.+?\])\.join''', data, re.DOTALL)[0]
            except IndexError:
                link = re.findall(r'''file:.*['"](http.+?)['"]\,''', data, re.DOTALL)[0]

            flink = link.replace('[', '').replace(']', '').replace('"', '').replace(',', '').replace('\/', '/')
            stream_headers = {'Referer': host.split('embed')[0], 'User-Agent':ua_win}
            stream_url = xbmc_curl_encode(flink, stream_headers)
        else:
            try:
                frame = json.loads(r).get('url')
            except:
                frame = client.parseDOM(r, 'iframe', ret='src')[-1]
            # xbmc.log('FRAME: {}'.format(frame))
            referer = '{uri.scheme}://{uri.netloc}'.format(uri=urlparse(frame))
            data = six.ensure_str(client.request(frame, referer=url, output=url))
            try:
                data = re.findall(r'''script>(eval.+?\{\}\))\)''', data, re.DOTALL)[-1]
                from resources.modules import jsunpack
                data = six.ensure_text(jsunpack.unpack(str(data) + ')'), encoding='utf-8')
            except:
                pass
            #xbmc.log('DATAAAA: {}'.format(data))

            if '"h","t","t","p"' in data:
                link = re.findall(r'''return\((\[.+?\])\.join''', data, re.DOTALL)[0]
                link = json.loads(link)
                link = "".join(link)
                flink = link.replace('////', '//')

            elif 'player.src({src:' in data:
                flink = re.findall(r'''player.src\(\{src:\s*["'](.+?)['"]\,''', data, re.DOTALL)[0]
            elif 'hlsjsConfig' in data and not 'new Clappr' in data:
                try:
                    if 'data-page=' in data:
                        data_page = client.parseDOM(data, 'div', ret='data-page', attrs={'id': 'app'})[0]
                        data_page = client.replaceHTMLCodes(data_page)
                        try:
                            data_page = data_page.replace('\/', '/')
                            flink = re.findall(r'''(https?:\/\/[^\s]+\.m3u8)''', data_page, re.DOTALL)[0]
                        except:
                            data_page = json.loads(data_page)
                            flink = data_page['props']['streamData']['streamurl']
                    else:
                        xbmcgui.Dialog().textviewer('data', str(data))
                        hlsurl, pk, ea = \
                            re.findall('.*hlsUrl\s*=\s*"(.*?&\w+=)".*?var\s+\w+\s*=\s*"([^"]+).*?>\s*ea\s*=\s*"([^"]+)', data,
                                       re.DOTALL)[0]
                        pk = pk[:53] + pk[53 + 1:]
                        link = hlsurl.replace('" + ea + "', ea) + pk
                        link_data = six.ensure_str(client.request(link))
                        flink = re.findall('.*(http.+?$)', link_data)[0]
                except Exception as e:
                    xbmcgui.Dialog().textviewer('e', str(e))
                    flink = re.findall(r'''src=\s*["'](.+?)['"]''', data, re.DOTALL)[0]
            elif 'new Clappr' in data:
                flink = re.findall(r'''source\s*:\s*["']?(.+?)['"]?\,''', str(data), re.DOTALL)[0]
                #xbmc.log('FLINKKK: {}'.format(flink))
                if flink == "m3u8Url" or flink == "m3u8":
                    html = six.ensure_str(data)
                    m = re.search(r'const\s+CHANNEL_KEY\s*=\s*["\']([\w-]+)["\']', html)
                    if not m:
                        raise Exception('CHANNEL_KEY not found')
                    channel_key = m.group(1)

                    m = re.search(r'const\s+BUNDLE\s*=\s*["\']([A-Za-z0-9+/=]+)["\']', html)
                    if not m:
                        raise Exception('BUNDLE not found')
                    bundle_b64 = m.group(1)

                    parts_raw = base64.b64decode(bundle_b64)
                    parts = json.loads(six.ensure_str(parts_raw))
                    for k in list(parts.keys()):
                        try:
                            parts[k] = six.ensure_str(base64.b64decode(parts[k]))
                        except Exception:
                            pass

                    auth_url = (
                            parts.get('b_host', '') +
                            parts.get('b_script', '') +
                            '?channel_id=' + quote_plus(channel_key) +
                            '&ts=' + quote_plus(parts.get('b_ts', '')) +
                            '&rnd=' + quote_plus(parts.get('b_rnd', '')) +
                            '&sig=' + quote_plus(parts.get('b_sig', ''))
                    )

                    pu = urlparse(referer)
                    origin = '{}://{}'.format(pu.scheme or 'https', pu.netloc)
                    ref_for_headers = frame or referer
                    try:
                        client.request(auth_url, referer=ref_for_headers)
                    except:
                        pass

                    #server_lookup για server_key
                    lookup_url = urljoin(origin, '/server_lookup.php?channel_id=' + quote_plus(channel_key))
                    body = six.ensure_str(client.request(lookup_url, referer=ref_for_headers))

                    server_key = ''
                    try:
                        resp = json.loads(body)
                        server_key = six.ensure_str(resp.get('server_key', '')).strip()
                    except Exception:
                        m = re.search(r'"server_key"\s*:\s*"([^"]+)"', body)
                        if m:
                            server_key = six.ensure_str(m.group(1)).strip()

                    if not server_key:
                        raise Exception('server_key not found')

                    sk_slug = server_key.strip().strip('/')  # π.χ. 'x4-cdn' ή 'x4-cdn/cdn'
                    if sk_slug == 'top1/cdn':
                        candidates = [
                            'https://top1.newkso.ru/top1/cdn/{}/mono.m3u8'.format(channel_key),
                            'http://top1.newkso.ru/top1/cdn/{}/mono.m3u8'.format(channel_key),
                        ]
                    else:
                        host_prefix = sk_slug.replace('/', '.')  # 'x4-cdn.cdn' αν έχει subpath
                        candidates = [
                            'https://{}.new.newkso.ru/{}/{}/mono.m3u8'.format(host_prefix, sk_slug, channel_key),
                            'https://new.newkso.ru/{}/{}/mono.m3u8'.format(sk_slug, channel_key),
                            'http://{}.new.newkso.ru/{}/{}/mono.m3u8'.format(host_prefix, sk_slug, channel_key),
                            'http://new.newkso.ru/{}/{}/mono.m3u8'.format(sk_slug, channel_key),
                        ]

                    candidates = [re.sub(r'(?<!:)/{2,}', '/', u) for u in candidates]
                    working = None
                    for u in candidates:
                        try:
                            chunk = client.request(u, referer=ref_for_headers)
                            s = six.ensure_str(chunk) if chunk is not None else ''
                            if s.startswith('#EXTM3U') or len(s) > 0:
                                working = u
                                break
                        except Exception as e:
                            xbmc.log('probe fail: {} -> {}'.format(u, e), xbmc.LOGDEBUG)
                            continue

                    if not working:
                        working = candidates[0]
                    #xbmc.log('FLINK (new Clappr): {}'.format(working))
                    flink = working


                elif flink == "src":
                    flink = re.findall(r'''src=\s*["'](.+?)['"]''', data, re.DOTALL)[0]
            elif 'player.setSrc' in data:
                flink = re.findall(r'''player.setSrc\(["'](.+?)['"]\)''', data, re.DOTALL)[0]
            elif 'new Player(' in data:
                player = re.findall(r'''new Player(\(.+?\))''', data,
                                    re.DOTALL)[0]
                import ast, random
                player = ast.literal_eval(player)
                p1 = player[3]
                p2 = random.choice(list(player[4].keys()))
                flink = 'https://{}/hls/{}/live.m3u8'.format(p2, p1)
            else:
                try:
                    data = data.replace('\/','/')
                    flink = re.findall(r'(https?:\/\/[^\s]+\.m3u8)', data, re.DOTALL)[0]
                except:
                    try:
                        flink = re.findall(r'''source:\s*["'](.+?)['"]''', data, re.DOTALL)[0]
                    except IndexError:
                        ea = re.findall(r'''ajax\(\{url:\s*['"](.+?)['"],''', data, re.DOTALL)[0]
                        ea = six.ensure_text(client.request(ea)).split('=')[1]
                        flink = re.findall('''videoplayer.src = "(.+?)";''', ea, re.DOTALL)[0]
                        flink = flink.replace('" + ea + "', ea)
            stream_headers = {'Referer': referer+'/', 'Origin': referer, 'User-Agent':ua_win, 'Connection':'keep-alive'}
            stream_url = xbmc_curl_encode(flink, stream_headers)
    elif '//dabac' in url:
        Dialog.notification(NAME, "[COLOR skyblue]Attempting To Resolve Link Now[/COLOR]", ICON, 2000, False)
        referer = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(url))
        frame = referer + "api/player.php?id={}"
        id = url.split("id=")[-1]
        nurl = frame.format(id)
        data = six.ensure_text(client.request(nurl))
        #xbmc.log("DATAAAAAA: {}".format(data))
        url = json.loads(data)["url"]
        data = requests.get(url, headers=headers, timeout=10).text
        iframe = re.findall(r'<iframe[^>]+src="([^"]+?)\+encodeURIComponent\(document\.referrer\)', data, re.DOTALL)[-1]
        ref = '{uri.scheme}://{uri.netloc}/'.format(uri=urlparse(iframe))
        iframe += quote_plus(referer)
        hdr = {
            'User-Agent': ua_win,  # ή ua_mob
            'Referer': url,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8'
        }
        data = six.ensure_text(requests.get(iframe, headers=hdr, timeout=10).text)
        #xbmc.log("DATAAAAAA2: {}".format(data))
        m = re.search(r'id="crf__"\s+value=[\'"]([^\'"]+)', data)
        if m:
            b64url = m.group(1)
            flink = base64.b64decode(b64url).decode("utf-8")
            stream_headers = {'Referer': ref + '/', 'Origin': ref, 'User-Agent': 'iPad'}
            stream_url = xbmc_curl_encode(flink, stream_headers)

    else:
        stream_url = url

    # `name` here is the EVENT title (we pass it as "description" in addDir for play_stream mode)
    event_title = six.ensure_text(name, encoding='utf-8', errors='ignore') if name is not None else u''

    xbmc.log('resolve2: final stream_url=%s' % stream_url, xbmc.LOGINFO)
    # Keep path for playback, but show event title in player UI/OSD
    try:
        liz = xbmcgui.ListItem(label=event_title, path=stream_url)
    except TypeError:
        # Older Kodi/Python API fallback
        liz = xbmcgui.ListItem(event_title)
        liz.setPath(stream_url)
    liz.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': FANART})
    liz.setProperty("IsPlayable", "true")

    # Prefer modern InfoTagVideo API (avoids setInfo deprecation warnings)
    try:
        tag = liz.getVideoInfoTag()
        tag.setTitle(event_title)
    except Exception:
        # Backward compatible fallback
        try:
            liz.setInfo('video', {'title': event_title})
        except TypeError:
            liz.setInfo(type="Video", infoLabels={'title': event_title})

    # IMPORTANT: succeeded must be True, otherwise Kodi treats it as a failure and won't play.
    try:
        xbmc.log('resolve2: using xbmcplugin.setResolvedUrl', xbmc.LOGINFO)
        xbmcplugin.setResolvedUrl(_handle, True, liz)
    except Exception as e:
        xbmc.log('resolve2: setResolvedUrl failed, falling back to xbmc.Player().play(): %s' % e, xbmc.LOGWARNING)
        xbmc.Player().play(stream_url, liz, False)



################################################################################
#########################CHANNELS HELPERS#######################################
################################################################################

xbmcvfs.mkdir(control.translatePath(ADDON_DATA))
JSON_FILE_PATH = control.translatePath(ADDON_DATA + 'channels.json')
LAST_UPDATE_FILE = control.translatePath(ADDON_DATA + 'last_update.txt')


def is_time_to_update(hours=6):
    if not xbmcvfs.exists(LAST_UPDATE_FILE):
        f = control.openFile(LAST_UPDATE_FILE, 'w')
        f.write(str(time.time()))
        f.close()
    f = control.openFile(LAST_UPDATE_FILE, 'r')
    content = f.read()
    last_update_timestamp = float(content.strip())
    f.close()

    hours_in_seconds = hours * 60 * 60
    current_time = time.time()

    return (current_time - last_update_timestamp) >= hours_in_seconds


def fetch_and_store_channel_data():
    hdrs = {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36'}
    try:
        url = BASEURL + '''api/trpc/mutual.getTopTeams,saves.getAllUserSaves,mutual.getFooterData,mutual.getAllChannels,mutual.getWebsiteConfig?batch=1&input={"0":{"json":null,"meta":{"values":["undefined"]}},"1":{"json":null,"meta":{"values":["undefined"]}},"2":{"json":null,"meta":{"values":["undefined"]}},"3":{"json":null,"meta":{"values":["undefined"]}},"4":{"json":null,"meta":{"values":["undefined"]}}}'''
        response = six.ensure_text(client.request(url, headers=hdrs), encoding='utf-8', errors='ignore')
        new_data = json.loads(response)

        new_channels_data = None
        for result in new_data:
            if ("result" in result and "data" in result["result"] and
                    "json" in result["result"]["data"] and "allChannels" in result["result"]["data"]["json"]):
                new_channels_data = result["result"]["data"]["json"]["allChannels"]
                break

        if not new_channels_data:
            return

        if not xbmcvfs.exists(JSON_FILE_PATH):
            existing_data = []
        else:
            file = xbmcvfs.File(JSON_FILE_PATH)
            existing_data = json.load(file)
            file.close()

        existing_data_map = {channel['_id']: channel for channel in existing_data}
        changes_made = False

        for new_channel in new_channels_data:
            channel_id = new_channel['_id']
            if channel_id not in existing_data_map or new_channel['links'] != existing_data_map[channel_id]['links']:
                existing_data_map[channel_id] = new_channel
                changes_made = True

        if changes_made:
            file = xbmcvfs.File(JSON_FILE_PATH, 'w')
            file.write(json.dumps(list(existing_data_map.values())))
            file.close()
            print("Channel links updated")

    except Exception as e:
        print("Error fetching or updating channel data: {}".format(e))


def load_data_from_json():
    f = control.openFile(JSON_FILE_PATH, 'r')
    contents = f.read()
    f.close()
    return json.loads(contents)


def get_links_for_channel(channel_name):
    channels_data = load_data_from_json()
    for channel in channels_data:
        datos = []
        if channel['channelName'] == channel_name:
            for link in channel['links']:
                chan = channel['channelName']
                lang = channel['language']
                datos.append((chan, link, lang))
            return datos
        else:
            if channel['channelName'].replace(' ', '') == channel_name.replace(' ', ''):
                for link in channel['links']:
                    chan = channel['channelName']
                    lang = channel['language']
                    datos.append((chan, link, lang))
                return datos
    return None


###################################################
###################################################
###################################################
########### Time and Date Helpers #################
###################################################
def fetch_user_timezone():
    try:
        locale_timezone = json.loads(xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}'))

        if locale_timezone['result']['value']:
            local_tzinfo = gettz(locale_timezone['result']['value'])
            if local_tzinfo:
                xbmc.log('SHOW FINAL ΤΙΜΕΖΟΝΕ: {}'.format(local_tzinfo))
                return local_tzinfo
            else:
                xbmc.log("Failed to get tzinfo for timezone: {}".format(locale_timezone['result']['value']))
        else:
            xbmc.log("No timezone value found in Kodi settings")
    except Exception as e:
        xbmc.log("Error fetching timezone from Kodi settings: {}".format(e))

    return gettz()


def convDateUtil(timestring, newfrmt='default', in_zone='UTC'):
    if newfrmt == 'default':
        newfrmt = xbmc.getRegion('time').replace(':%S', '')
    try:
        local_tzinfo = fetch_user_timezone()
        in_time = parse(timestring)
        in_time_with_timezone = in_time.replace(tzinfo=gettz(in_zone))
        local_time = in_time_with_timezone.astimezone(local_tzinfo)
        return local_time.strftime(newfrmt)
    except:
        return timestring


def pelota_time_to_local(time_str, date_iso=None, in_zone='Europe/Madrid'):
    """
    Pelota agenda provides only a clock time (e.g. "18:00") and a page-level agenda date.
    We assume the clock time is in `in_zone` (Pelota agenda matches Europe/Madrid in practice)
    and convert to the user's Kodi timezone (per-device via fetch_user_timezone()).
    
    Note: we intentionally return ONLY the local time (no date) even if the conversion crosses midnight.
    """
    try:
        dt_local = pelota_event_dt_local(time_str, date_iso=date_iso, in_zone=in_zone)
        if not dt_local:
            return time_str
        time_fmt = xbmc.getRegion('time').replace(':%S', '')
        return dt_local.strftime(time_fmt)
    except Exception:
        return time_str


def pelota_event_dt_local(time_str, date_iso=None, in_zone='Europe/Madrid', date_zone='America/Bogota'):
    """
    Returns an aware datetime in the user's Kodi timezone for a Pelota event start time.
    Uses `date_iso` ("YYYY-MM-DD") when available.

    Important nuance (Pelota agenda behavior):
    - The *agenda date* appears to be in `date_zone` (e.g. Colombia),
    - while the *clock time* in the HTML appears to be in `in_zone` (e.g. Spain).
    We reconcile by choosing the datetime in `in_zone` whose date, when converted to `date_zone`,
    matches `date_iso`.
    """
    try:
        s = six.ensure_text(time_str, encoding='utf-8', errors='ignore') if time_str is not None else u''
        m = re.search(r'(\d{1,2})\s*:\s*(\d{2})', s)
        if not m:
            return None

        hh = int(m.group(1))
        mm = int(m.group(2))

        local_tz = fetch_user_timezone()

        base_date = None
        if date_iso:
            try:
                y, mo, d = [int(x) for x in six.ensure_text(date_iso).split('-')]
                base_date = datetime(y, mo, d).date()
            except Exception:
                base_date = None

        # If no date is available, fall back to "today" in the user's timezone.
        # (This is best-effort; Pelota should ideally always provide the agenda date.)
        if base_date is None:
            base_date = datetime.now(local_tz).date()

        tz_in = gettz(in_zone)
        tz_date = gettz(date_zone)

        # Candidate in the "clock" timezone
        dt_in = datetime(base_date.year, base_date.month, base_date.day, hh, mm, tzinfo=tz_in)

        # Adjust +/- 1 day so that the *date in date_zone* matches base_date
        try:
            date_in_date_zone = dt_in.astimezone(tz_date).date()
            if date_in_date_zone < base_date:
                dt_in = dt_in + timedelta(days=1)
            elif date_in_date_zone > base_date:
                dt_in = dt_in - timedelta(days=1)
        except Exception:
            pass

        return dt_in.astimezone(local_tz)
    except Exception:
        return None


def time_convert(timestamp):
    timestamp = int(str(timestamp)[:10])
    dt_object = datetime.fromtimestamp(timestamp)
    time_ = dt_object.strftime("%d-%b, %H:%M")
    return time_


def time_to_update(hours=6):
    try:
        f = control.openFile(LAST_UPDATE_FILE, 'r')
        content = f.read()
        last_update_timestamp = float(content.strip())
        f.close()
    except:
        return True

    hours_in_seconds = int(hours) * 60 * 60
    current_time = time.time()

    return (current_time - last_update_timestamp) >= hours_in_seconds


def update_last_update_time():
    try:
        f = control.openFile(LAST_UPDATE_FILE, 'w')
        f.write(str(time.time()))
        f.close()
    except:
        print("Error updating last update time")


def adjust_date_and_convert_to_timestamp_ms(matchDate, livetvtimestr):
    date_obj = parser.parse(matchDate[2:])
    hours, minutes = map(int, livetvtimestr.split(":"))
    date_obj = date_obj.replace(hour=hours, minute=minutes)

    date_obj += timedelta(days=1)
    user_timezone = fetch_user_timezone()
    date_obj = date_obj.astimezone(user_timezone)

    if six.PY2:
        timestamp_ms = int((time.mktime(date_obj.timetuple()) + date_obj.microsecond / 1e6) * 1000)
    else:
        timestamp_ms = int(date_obj.timestamp() * 1000)
    return timestamp_ms


##########################################################################################
##########################################################################################


def Open_settings():
    control.openSettings()


def addDir(name, url, mode, iconimage, description, isFolder=True, infoLabels=None):
    """
    Build and add a Kodi directory item.

    - **Kodi docs**: use `xbmcgui.ListItem` + `xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder)`.
    - We keep your existing query parameters (`url`, `mode`, `name`, `iconimage`, `description`) for router compatibility.
    - We also fix "playable" handling: playback modes must set `IsPlayable` and be `isFolder=False`.
    """

    # Normalize to text (works for both Py2/Py3 via six)
    name = six.ensure_text(name, encoding='utf-8', errors='ignore') if name is not None else u''
    url = six.ensure_text(url, encoding='utf-8', errors='ignore') if url is not None else u''
    mode = six.ensure_text(mode, encoding='utf-8', errors='ignore') if mode is not None else u''
    iconimage = six.ensure_text(iconimage, encoding='utf-8', errors='ignore') if iconimage is not None else u''
    description = six.ensure_text(description, encoding='utf-8', errors='ignore') if description is not None else u''

    # Build plugin callback URL safely
    params = {
        'url': url,
        'mode': mode,
        'name': name,
        'iconimage': iconimage,
        'description': description
    }
    u = _url + '?' + urlencode(params)

    # Create list item
    try:
        liz = xbmcgui.ListItem(label=name)
    except TypeError:
        # Older Kodi/Python API fallback
        liz = xbmcgui.ListItem(name)

    art_icon = iconimage or ICON
    liz.setArt({
        'icon': art_icon,
        'thumb': art_icon,
        'poster': art_icon,
        'fanart': FANART
    })

    # Decide playability / folder-ness
    non_playable_modes = {'settings', 'version', 'clear', ''}
    playable_modes = {'play_stream', 'futbollibre_play', 'footie_play', 'footie_open'}

    if mode in playable_modes:
        isFolder = False
        liz.setProperty('IsPlayable', 'true')
    elif not isFolder and mode not in non_playable_modes:
        liz.setProperty('IsPlayable', 'true')

    # Metadata
    labels = {}
    if isinstance(infoLabels, dict):
        labels.update(infoLabels)
    if description and 'plot' not in labels:
        labels['plot'] = description
    if name and 'title' not in labels:
        labels['title'] = name

    if labels:
        try:
            liz.setInfo('video', labels)
        except TypeError:
            # Old signature: setInfo(type="Video", infoLabels={...})
            liz.setInfo(type="Video", infoLabels=labels)

    xbmcplugin.addDirectoryItem(_handle, url=u, listitem=liz, isFolder=isFolder)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['mode'] == 'events':
            if time_to_update():
                fetch_and_store_channel_data()
                update_last_update_time()
            else:
                print("Not yet time to check for updates.")
            get_events(params['url'])

        elif params['mode'] == 'all_events':
            show_all_events()

        elif params['mode'] == 'futbollibre_events':
            show_futbollibre_events()
        elif params['mode'] == 'futbollibre_streams':
            show_futbollibre_streams(params['url'])
        elif params['mode'] == 'futbollibre_play':
            futbollibre_play(params['url'], params.get('description', ''))
        elif params['mode'] == 'footie_events':
            show_footie_events()
        elif params['mode'] == 'footie_streams':
            show_footie_streams(params['url'])
        elif params['mode'] == 'footie_play':
            footie_play(params['url'], params.get('description', ''))
        elif params['mode'] == 'footie_highlights':
            show_footie_highlights()
        elif params['mode'] == 'footie_open':
            _platform_open_url(params.get('url', ''))
        elif params['mode'] == 'get_streams':
            get_stream(params['name'], params['url'])
        elif params['mode'] == 'play_stream':
            resolve2(params['description'], params['url'])
        elif params['mode'] == 'settings':
            Open_settings()
        elif params['mode'] == 'clear':
            control.deleteFile(LAST_UPDATE_FILE)
            control.infoDialog("[COLOR gold]Files cleared[/COLOR]", NAME,
                               ICON, 5000)
        elif params['mode'] == 'version':
            xbmc.executebuiltin('UpdateAddonRepos')
    else:
        Main_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])
