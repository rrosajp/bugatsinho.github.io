# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import re
import base64
import requests
import six

from six.moves.urllib.parse import quote_plus, urlparse, parse_qs


AGENDA_URL = 'https://pelota-libre.net/agenda/'
UA = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36'
SESSION = requests.Session()

# Cache για να ΜΗΝ ξαναχτυπάμε την agenda
_LAST_EVENTS = None


def http_get(url, referer=None):
    headers = {'User-Agent': UA}
    if referer:
        headers['Referer'] = referer
    try:
        r = SESSION.get(url, headers=headers, timeout=10, verify=False)
        r.raise_for_status()
        text = six.ensure_text(r.text, encoding='utf-8', errors='ignore')
        return text
    except Exception as e:
        try:
            print('pelota::http_get error: %s (%s)' % (url, e))
        except Exception:
            pass
        return ''


def _clean(txt):
    txt = re.sub(r'<[^>]+>', '', txt)
    txt = txt.replace('&nbsp;', ' ')
    return ' '.join(txt.split()).strip()


def _parse_agenda():
    """
    Κάνει ΜΟΝΟ ΕΝΑ request στο AGENDA_URL και γεμίζει
    το _LAST_EVENTS με events + streams.
    """
    global _LAST_EVENTS

    html = http_get(AGENDA_URL)
    events = []

    # Agenda header example:
    # "Agenda - Viernes 12 de Diciembre de 2025"
    # We capture the date so the addon can do correct timezone conversion (incl. day rollovers).
    agenda_date = None  # ISO "YYYY-MM-DD"
    try:
        m = re.search(r'Agenda\s*-\s*[^0-9]*?(\d{1,2})\s+de\s+([A-Za-zñÑ]+)\s+de\s+(\d{4})', html, re.IGNORECASE)
        if m:
            day = int(m.group(1))
            mon_txt = m.group(2).strip().lower()
            year = int(m.group(3))
            months = {
                'enero': 1, 'febrero': 2, 'marzo': 3, 'abril': 4, 'mayo': 5, 'junio': 6,
                'julio': 7, 'agosto': 8, 'septiembre': 9, 'setiembre': 9, 'octubre': 10,
                'noviembre': 11, 'diciembre': 12
            }
            mon = months.get(mon_txt)
            if mon:
                agenda_date = '%04d-%02d-%02d' % (year, mon, day)
    except Exception:
        agenda_date = None

    # <li class="FIFA"> ... <a href="#">ΤΙΤΛΟΣ<span class="t">18:00</span></a> <ul>...streams...</ul> </li>
    ev_pat = re.compile(
        r'<li\s+class="([^"]+)">\s*'
        r'<a\s+href="#">\s*(.*?)'
        r'<span\s+class="t">\s*([^<]+)\s*</span>\s*</a>\s*'
        r'<ul>(.*?)</ul>\s*</li>',
        re.DOTALL | re.IGNORECASE
    )

    stream_pat = re.compile(
        r'<li\s+class="subitem1">\s*'
        r'<a\s+href="([^"]+)"[^>]*>'
        r'([^<]+)'
        r'(?:<span>([^<]*)</span>)?'
        r'</a>\s*</li>',
        re.DOTALL | re.IGNORECASE
    )

    idx = 0
    for m in ev_pat.finditer(html):
        category = m.group(1).strip()
        title = _clean(m.group(2))
        time_ = m.group(3).strip()
        block = m.group(4)

        streams = []
        for s in stream_pat.finditer(block):
            href = s.group(1).strip()
            name = _clean(s.group(2))
            quality = _clean(s.group(3)) if s.group(3) else ''
            streams.append({
                'name': name,
                'quality': quality,
                'url': href,
            })

        events.append({
            'id': idx,
            'category': category,
            'title': title,
            'time': time_,
            'date': agenda_date,
            'streams': streams,
        })
        idx += 1

    _LAST_EVENTS = events
    return events


# -----------------------------
# Public API για το default.py
# -----------------------------
def list_events():
    """Επιστρέφει λίστα από events (ΧΩΡΙΣ streams)."""
    global _LAST_EVENTS
    if _LAST_EVENTS is None:
        _parse_agenda()
    # Επιστρέφουμε μόνο ό,τι χρειάζεται για το μενού
    return [
        {
            'id': ev['id'],
            'category': ev['category'],
            'title': ev['title'],
            'time': ev['time'],
            'date': ev.get('date'),
        }
        for ev in _LAST_EVENTS
    ]


def get_streams(title, time_):
    """Επιστρέφει τις streams για συγκεκριμένο event ΧΩΡΙΣ νέο request."""
    global _LAST_EVENTS
    if _LAST_EVENTS is None:
        _parse_agenda()

    # Βρίσκουμε το event με βάση title + time
    for ev in _LAST_EVENTS:
        if ev['title'] == title and ev['time'] == time_:
            return ev['streams']

    # Αν για κάποιο λόγο δεν βρέθηκε, κάνε μία φορά refresh και ξαναψάξε
    _parse_agenda()
    for ev in _LAST_EVENTS:
        if ev['title'] == title and ev['time'] == time_:
            return ev['streams']

    return []


def _decode_pelota_redirect(url):
    """Decode του ?r=BASE64 από Pelota."""
    try:
        parsed = urlparse(url)
        qs = parse_qs(parsed.query)
        r_val = qs.get('r', [None])[0]
        if not r_val:
            return url

        r_val = r_val.strip()
        missing = len(r_val) % 4
        if missing:
            r_val += '=' * (4 - missing)

        decoded = base64.b64decode(r_val)
        try:
            decoded = decoded.decode('utf-8', 'ignore')
        except Exception:
            pass

        if decoded:
            return decoded
    except Exception:
        pass
    return url


def resolve(url):
    """
    Τελικό resolve:
    - eventos/?r=... → decode
    - αν ΔΕΝ είναι envivos.org → βρίσκουμε <iframe src="https://envivos.org/...">
    - μπαίνουμε στη σελίδα envivos, βρίσκουμε playbackURL ή .m3u8
    - επιστροφή m3u8 με Kodi headers (Referer + UA)
    """

    original = url
    referer = None

    # 1) eventos/?r=...
    if 'pelota-libre.net/eventos/' in url:
        referer = url
        url = _decode_pelota_redirect(url)

    current = url

    # 2) Αν δεν είναι envivos.org, είναι wrapper → βρίσκουμε iframe
    if 'envivos.org' not in current:
        html = http_get(current, referer=referer or original)
        if html:
            m_if = re.search(r'<iframe[^>]+src="([^"]+)"', html, re.IGNORECASE)
            if m_if:
                src = m_if.group(1).strip()
                if src.startswith('//'):
                    p = urlparse(current)
                    src = p.scheme + ':' + src
                elif src.startswith('/'):
                    p = urlparse(current)
                    src = p.scheme + '://' + p.netloc + src
                current = src

    # 3) Αν ήδη .m3u8
    if '.m3u8' in current:
        hdr_ref = referer or original or current
        return current + '|Referer=' + quote_plus(hdr_ref) + '&User-Agent=' + quote_plus(UA)

    # 4) Σελίδα envivos.org (π.χ. canal.php?stream=foxsports)
    html_env = http_get(current, referer=referer or original or current)
    if not html_env:
        return current

    # var playbackURL = "https://...m3u8..."
    m = re.search(r'var\s+playbackURL\s*=\s*["\']([^"\']+)["\']', html_env, re.IGNORECASE)
    if m:
        m3u8 = m.group(1).strip()
        hdr_ref = current
        return m3u8 + '|Referer=' + quote_plus(hdr_ref) + '&User-Agent=' + quote_plus(UA)

    # fallback: οποιοδήποτε .m3u8
    m2 = re.search(r'(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)', html_env, re.IGNORECASE)
    if m2:
        m3u8 = m2.group(1).strip()
        hdr_ref = current
        return m3u8 + '|Referer=' + quote_plus(hdr_ref) + '&User-Agent=' + quote_plus(UA)

    return current