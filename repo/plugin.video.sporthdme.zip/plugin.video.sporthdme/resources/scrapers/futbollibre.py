# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import base64
import json
import re
import requests
import six

from six.moves.urllib.parse import quote_plus, urlparse, parse_qs

AGENDA_JSON_URL = 'https://futbollibre.ws/agenda.json'
UA = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36'
SESSION = requests.Session()

# Cache so we don't refetch repeatedly
_LAST = None


def http_get_json(url):
    headers = {'User-Agent': UA}
    try:
        r = SESSION.get(url, headers=headers, timeout=12, verify=False)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        try:
            print('futbollibre::http_get_json error: %s (%s)' % (url, e))
        except Exception:
            pass
        return None


def _parse_es_date_to_iso(txt):
    """
    Parses Spanish date strings like:
      - "Viernes 12 de Diciembre de 2025"
      - "Agenda Deportiva – Viernes 12 de Diciembre de 2025"
    Returns ISO "YYYY-MM-DD" or None.
    """
    if not txt:
        return None
    try:
        t = six.ensure_text(txt, encoding='utf-8', errors='ignore')
        m = re.search(r'(\d{1,2})\s+de\s+([A-Za-zñÑ]+)\s+de\s+(\d{4})', t, re.IGNORECASE)
        if not m:
            return None
        day = int(m.group(1))
        mon_txt = m.group(2).strip().lower()
        year = int(m.group(3))
        months = {
            'enero': 1, 'febrero': 2, 'marzo': 3, 'abril': 4, 'mayo': 5, 'junio': 6,
            'julio': 7, 'agosto': 8, 'septiembre': 9, 'setiembre': 9, 'octubre': 10,
            'noviembre': 11, 'diciembre': 12
        }
        mon = months.get(mon_txt)
        if not mon:
            return None
        return '%04d-%02d-%02d' % (year, mon, day)
    except Exception:
        return None


def _normalize_agenda(data):
    """
    Normalizes agenda.json to a flat list of events with channels.
    We generate our own stable ids (incremental).
    """
    days = (data or {}).get('dias') or []
    events = []
    idx = 0
    for d in days:
        # Many builds include "fecha" as a spanish date string
        date_iso = _parse_es_date_to_iso(d.get('fecha', '')) or d.get('date') or d.get('fechaISO')
        for ev in (d.get('eventos') or []):
            icon_url = ev.get('iconUrl') or ev.get('icon') or ''
            title = ev.get('titulo') or ev.get('title') or ''
            time_ = ev.get('hora') or ev.get('time') or ''
            league = ev.get('clase') or ev.get('liga') or ''
            channels = ev.get('canales') or ev.get('channels') or []

            events.append({
                'id': idx,
                'date': date_iso,
                'time': six.ensure_text(time_, encoding='utf-8', errors='ignore'),
                'title': six.ensure_text(title, encoding='utf-8', errors='ignore'),
                'league': six.ensure_text(league, encoding='utf-8', errors='ignore'),
                'icon': six.ensure_text(icon_url, encoding='utf-8', errors='ignore'),
                'streams': channels
            })
            idx += 1
    return events


def _refresh():
    global _LAST
    data = http_get_json(AGENDA_JSON_URL)
    if not data:
        _LAST = {'events': []}
        return _LAST
    _LAST = {'events': _normalize_agenda(data)}
    return _LAST


# -----------------------------
# Public API for default.py
# -----------------------------
def list_events():
    """
    Returns list of events WITHOUT streams payload.
    Each event contains: id, title, time, date, league, icon.
    """
    global _LAST
    if _LAST is None:
        _refresh()
    return [
        {
            'id': ev['id'],
            'title': ev.get('title', ''),
            'time': ev.get('time', ''),
            'date': ev.get('date'),
            'league': ev.get('league', ''),
            'icon': ev.get('icon', ''),
        }
        for ev in (_LAST or {}).get('events', [])
    ]


def get_streams(event_id):
    """
    Returns streams for a given event_id WITHOUT additional HTTP requests.
    """
    global _LAST
    if _LAST is None:
        _refresh()
    try:
        eid = int(event_id)
    except Exception:
        eid = None
    for ev in (_LAST or {}).get('events', []):
        if ev.get('id') == eid:
            return ev.get('streams') or []
    # refresh once and retry
    _refresh()
    for ev in (_LAST or {}).get('events', []):
        if ev.get('id') == eid:
            return ev.get('streams') or []
    return []


def _decode_r_param(url):
    """
    Futbollibre uses eventos.html?r=<base64 or raw>. We accept:
      - any url with ?r=...
      - raw base64 in `r`
    """
    try:
        parsed = urlparse(url)
        qs = parse_qs(parsed.query)
        r_val = qs.get('r', [None])[0]
        if not r_val:
            return url

        r_val = r_val.strip()
        # Try URL-safe base64 decode; pad if needed
        missing = len(r_val) % 4
        if missing:
            r_val += '=' * (4 - missing)

        try:
            decoded = base64.b64decode(r_val)
            try:
                decoded = decoded.decode('utf-8', 'ignore')
            except Exception:
                pass
            if decoded and decoded.startswith('http'):
                return decoded
        except Exception:
            pass
    except Exception:
        pass
    return url


def http_get_text(url, referer=None):
    headers = {'User-Agent': UA}
    if referer:
        headers['Referer'] = referer
    try:
        r = SESSION.get(url, headers=headers, timeout=12, verify=False)
        r.raise_for_status()
        return six.ensure_text(r.text, encoding='utf-8', errors='ignore')
    except Exception as e:
        try:
            print('futbollibre::http_get_text error: %s (%s)' % (url, e))
        except Exception:
            pass
        return ''


def resolve(url):
    """
    Best-effort resolver:
    - decode ?r=... payloads
    - follow wrapper pages to iframe
    - extract .m3u8 or playbackURL
    Returns final URL and (when possible) adds headers in Kodi pipe format.
    """
    original = url
    referer = None

    if not url:
        return url

    # Decode eventos.html?r=...
    if '?r=' in url:
        referer = url
        url = _decode_r_param(url)

    current = url

    # If already .m3u8, add headers and return
    if '.m3u8' in current:
        hdr_ref = referer or original or current
        return current + '|Referer=' + quote_plus(hdr_ref) + '&User-Agent=' + quote_plus(UA)

    # Wrapper → find iframe
    html = http_get_text(current, referer=referer or original)
    if html:
        m_if = re.search(r'<iframe[^>]+src="([^"]+)"', html, re.IGNORECASE)
        if m_if:
            src = m_if.group(1).strip()
            if src.startswith('//'):
                p = urlparse(current)
                src = p.scheme + ':' + src
            elif src.startswith('/'):
                p = urlparse(current)
                src = p.scheme + '://' + p.netloc + src
            current = src

    # If iframe now points to .m3u8
    if '.m3u8' in current:
        hdr_ref = referer or original or current
        return current + '|Referer=' + quote_plus(hdr_ref) + '&User-Agent=' + quote_plus(UA)

    # Try to extract playbackURL or any .m3u8 from iframe page
    html2 = http_get_text(current, referer=referer or original or current)
    if not html2:
        return current

    m = re.search(r'var\s+playbackURL\s*=\s*["\']([^"\']+)["\']', html2, re.IGNORECASE)
    if m:
        m3u8 = m.group(1).strip()
        return m3u8 + '|Referer=' + quote_plus(current) + '&User-Agent=' + quote_plus(UA)

    m2 = re.search(r'(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)', html2, re.IGNORECASE)
    if m2:
        m3u8 = m2.group(1).strip()
        return m3u8 + '|Referer=' + quote_plus(current) + '&User-Agent=' + quote_plus(UA)

    return current


