# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import re
import requests
import six
from datetime import datetime


UA = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36'
SESSION = requests.Session()

BASE = 'https://watchfootballhighlights.com'
HOME = 'https://watchfootballhighlights.com/'


def http_get(url):
    headers = {'User-Agent': UA}
    r = SESSION.get(url, headers=headers, timeout=12, verify=False)
    r.raise_for_status()
    return six.ensure_text(r.text, encoding='utf-8', errors='ignore')


def _abs(url):
    if not url:
        return url
    url = url.strip()
    if url.startswith('http://') or url.startswith('https://'):
        return url
    if url.startswith('/'):
        return BASE + url
    return BASE + '/' + url


def _parse_dt(date_str, time_str):
    """
    Parses 'YYYY-MM-DD' + '03:00 PM' (or similar) into naive datetime for sorting.
    """
    try:
        date_str = six.ensure_text(date_str, encoding='utf-8', errors='ignore').strip()
        time_str = six.ensure_text(time_str, encoding='utf-8', errors='ignore').strip()
        return datetime.strptime(date_str + ' ' + time_str, '%Y-%m-%d %I:%M %p')
    except Exception:
        return None


def list_highlights(url=HOME):
    """
    Returns highlight entries from the schedules page:
      {title, url, icon, league, date, time, dt}
    The site groups by tournament; we keep that info but return a flat list.
    """
    html = http_get(url)
    out = []

    current_league = ''
    current_league_icon = ''

    tokens = re.split(r'(<div class="top-tournament\\s+">|<a class="competition")', html)

    for i, tok in enumerate(tokens):
        if tok == '<div class="top-tournament ">':
            block = tokens[i + 1] if i + 1 < len(tokens) else ''
            m = re.search(r'<img[^>]+src="([^"]+)"[^>]*>\\s*</span>\\s*<span class="league-name">([^<]+)</span>', block, re.IGNORECASE)
            if m:
                current_league_icon = _abs(m.group(1))
                current_league = six.ensure_text(m.group(2), encoding='utf-8', errors='ignore').strip()
            continue

        if tok == '<a class="competition':
            rest = tokens[i + 1] if i + 1 < len(tokens) else ''
            # restore tag start
            chunk = '<a class="competition' + rest
            # href
            m_href = re.search(r'href="([^"]+)"', chunk, re.IGNORECASE)
            if not m_href:
                continue
            href = _abs(m_href.group(1))

            # teams
            teams = re.findall(r'<span class="name txt-team">\\s*([^<]+)</span>', chunk, re.IGNORECASE)
            team1 = six.ensure_text(teams[0], encoding='utf-8', errors='ignore').strip() if len(teams) > 0 else ''
            team2 = six.ensure_text(teams[1], encoding='utf-8', errors='ignore').strip() if len(teams) > 1 else ''

            # datetime
            m_time = re.search(r'<time[^>]*class="competition-cell-status"[^>]*>\\s*(\\d{4}-\\d{2}-\\d{2})\\s*<span class="match-time">\\s*([^<]+)\\s*</span>', chunk, re.IGNORECASE)
            date_str, time_str, dt = '', '', None
            if m_time:
                date_str = m_time.group(1).strip()
                time_str = ' '.join(m_time.group(2).split()).strip()
                dt = _parse_dt(date_str, time_str)

            # pick an icon: use first team image if available, else league icon
            m_img = re.search(r'<img[^>]+src="([^"]+/images/teams/[^"]+)"', chunk, re.IGNORECASE)
            icon = _abs(m_img.group(1)) if m_img else (current_league_icon or '')

            title = (u'{0} vs {1}'.format(team1, team2)).strip()
            if not title.strip(' vs '):
                title = href.split('/')[-2] if '/' in href else href

            out.append({
                'title': title,
                'url': href,
                'icon': icon,
                'league': current_league,
                'date': date_str,
                'time': time_str,
                'dt': dt
            })

    # Sort by datetime when available
    out = sorted(out, key=lambda x: x.get('dt') or datetime.max)
    return out


