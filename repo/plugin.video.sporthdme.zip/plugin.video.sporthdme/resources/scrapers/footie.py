# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import re
import time
import requests
import six


UA = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36'
SESSION = requests.Session()

BASE = 'https://www.footybite.to'
TODAY_URL = 'https://live.footybite.to/'

# Cache for match meta (sttime/title/league) to avoid refetching repeatedly
_META_CACHE = {}  # match_url -> {'ts': epoch_fetch_time, 'meta': {...}}
_META_TTL = 15 * 60  # seconds


def http_get(url):
    headers = {'User-Agent': UA}
    r = SESSION.get(url, headers=headers, timeout=12, verify=False)
    r.raise_for_status()
    return six.ensure_text(r.text, encoding='utf-8', errors='ignore')


def _abs(url):
    if not url:
        return url
    url = url.strip()
    if url.startswith('http://') or url.startswith('https://'):
        return url
    if url.startswith('/'):
        return BASE + url
    return url


def _parse_starts_in(txt):
    """
    Parses strings like:
      - "Starts in 1hr:48min"
      - "Starts in 48min"
      - "Match Started"
    Returns (is_live, seconds_to_start or None)
    """
    if not txt:
        return False, None
    t = ' '.join(txt.split()).strip()
    if 'Match Started' in t:
        return True, 0
    m = re.search(r'Starts\s+in\s+(?:(\d+)\s*hr:)?\s*(\d+)\s*min', t, re.IGNORECASE)
    if not m:
        return False, None
    h = int(m.group(1) or 0)
    mins = int(m.group(2) or 0)
    return False, (h * 3600 + mins * 60)


def list_events(url=TODAY_URL):
    """
    Returns a list of events:
      {league, league_icon, team1, team2, match_url, status_text, is_live, start_ts_est}
    start_ts_est is epoch seconds based on "Starts in" delta (best-effort).
    """
    html = http_get(url)
    out = []
    current_league = ''
    current_league_icon = ''

    # We iterate in document order so we can attach matches to the last seen league header.
    tokens = re.split(r'(<div class="my-1">|<a target="_blank" href=")', html)
    now = int(time.time())

    for i, tok in enumerate(tokens):
        # League header blocks
        if tok == '<div class="my-1">':
            block = tokens[i + 1] if i + 1 < len(tokens) else ''
            m = re.search(r'<img\s+src="([^"]+)"[^>]*alt="([^"]+)"[^>]*>.*?<span>([^<]+)</span>', block, re.DOTALL | re.IGNORECASE)
            if m:
                current_league_icon = _abs(m.group(1))
                current_league = six.ensure_text(m.group(3), encoding='utf-8', errors='ignore').strip()
            continue

        # Match link blocks
        if tok == '<a target="_blank" href="':
            rest = tokens[i + 1] if i + 1 < len(tokens) else ''
            m_url = re.match(r'([^"]+)"', rest)
            if not m_url:
                continue
            match_url = _abs(m_url.group(1))

            # Narrow block: take a slice until closing </a>
            block = rest.split('</a>', 1)[0]

            teams = re.findall(r'<span class="txt-team">([^<]+)</span>', block, re.IGNORECASE)
            if len(teams) >= 2:
                team1 = six.ensure_text(teams[0], encoding='utf-8', errors='ignore').strip()
                team2 = six.ensure_text(teams[1], encoding='utf-8', errors='ignore').strip()
            else:
                continue

            # Status
            m_status = re.search(r'<div class="col-2[^"]*time-txt[^"]*">[\s\S]*?<span class="">\s*([^<]+)\s*</span>', block, re.IGNORECASE)
            status_text = six.ensure_text(m_status.group(1), encoding='utf-8', errors='ignore').strip() if m_status else ''

            is_live, secs = _parse_starts_in(status_text)
            start_ts_est = None
            if secs is not None:
                start_ts_est = now + secs

            out.append({
                'league': current_league or 'Footie',
                'league_icon': current_league_icon,
                'team1': team1,
                'team2': team2,
                'match_url': match_url,
                'status_text': status_text,
                'is_live': bool(is_live),
                'start_ts_est': start_ts_est
            })

    return out


def get_match_meta(match_url):
    """
    Fetches match page and extracts lightweight metadata:
      {title, league, sttime}
    Cached for a short TTL.
    """
    try:
        now = int(time.time())
        cached = _META_CACHE.get(match_url)
        if cached and (now - int(cached.get('ts', 0))) < _META_TTL:
            return cached.get('meta') or {}

        html = http_get(match_url)

        title = ''
        league = ''
        m_meta = re.search(r'Watch\s+(.+?)\s+live streams Online,\s*([^,]+),', html, re.IGNORECASE)
        if m_meta:
            title = six.ensure_text(m_meta.group(1), encoding='utf-8', errors='ignore').strip()
            league = six.ensure_text(m_meta.group(2), encoding='utf-8', errors='ignore').strip()

        sttime = None
        m_st = re.search(r'var\s+sttime\s*=\s*"(\d+)"', html, re.IGNORECASE)
        if m_st:
            try:
                sttime = int(m_st.group(1))
            except Exception:
                sttime = None

        meta = {'title': title, 'league': league, 'sttime': sttime}
        _META_CACHE[match_url] = {'ts': now, 'meta': meta}
        return meta
    except Exception:
        return {}


def list_events_with_times(url=TODAY_URL):
    """
    Returns events enriched with match page sttime/title/league.
    Shape:
      {team1, team2, match_url, league, league_icon, sttime, is_live}
    NOTE: This performs one HTTP request per match (cached for TTL).
    """
    base = list_events(url=url)
    out = []
    for ev in base:
        meta = get_match_meta(ev.get('match_url', ''))
        st = meta.get('sttime')
        is_live = False
        if st:
            # lime if started; list doesn't include ended games usually, but keep a generous window anyway
            now = int(time.time())
            if now >= int(st) and now <= int(st) + (6 * 3600):
                is_live = True
        else:
            # fallback to the page status text
            is_live = bool(ev.get('is_live'))

        out.append({
            'team1': ev.get('team1', ''),
            'team2': ev.get('team2', ''),
            'match_url': ev.get('match_url', ''),
            'league': meta.get('league') or ev.get('league', ''),
            'league_icon': ev.get('league_icon', ''),
            'sttime': st,
            'is_live': is_live
        })

    # Sort by start time, unknown times last
    out = sorted(out, key=lambda x: int(x.get('sttime') or 9999999999))
    return out


def get_match_streams(match_url):
    """
    Parses match page and returns:
      {title, league, sttime (epoch seconds or None), streams:[{name,url}]}
    The page encodes stream URLs in hidden inputs: id="linkk<ID>" value="URL"
    and displays a clickable <td onclick="view(ID)">Name</td>
    """
    html = http_get(match_url)

    # Best title/league from meta description
    title = ''
    league = ''
    m_meta = re.search(r'Watch\s+(.+?)\s+live streams Online,\s*([^,]+),', html, re.IGNORECASE)
    if m_meta:
        title = six.ensure_text(m_meta.group(1), encoding='utf-8', errors='ignore').strip()
        league = six.ensure_text(m_meta.group(2), encoding='utf-8', errors='ignore').strip()

    sttime = None
    m_st = re.search(r'var\s+sttime\s*=\s*"(\d+)"', html, re.IGNORECASE)
    if m_st:
        try:
            sttime = int(m_st.group(1))
        except Exception:
            sttime = None

    links = {}
    for m in re.finditer(r'<input[^>]+type="hidden"[^>]+value="([^"]+)"[^>]+id="linkk(\d+)"', html, re.IGNORECASE):
        links[m.group(2)] = m.group(1)

    names = {}
    for m in re.finditer(r'onclick="view\((\d+)\)"[^>]*>[\s\S]*?</i>\s*([^<]+)</td>', html, re.IGNORECASE):
        names[m.group(1)] = ' '.join(m.group(2).split()).strip()

    streams = []
    for k, url in links.items():
        nm = names.get(k) or ('stream-%s' % k)
        streams.append({'name': nm, 'url': url})

    # Stable ordering: by name
    streams = sorted(streams, key=lambda x: x.get('name', ''))

    return {'title': title, 'league': league, 'sttime': sttime, 'streams': streams}


def list_highlights(url=TODAY_URL):
    """
    Uses the right sidebar 'Blog Soccer Streams' section as 'Highlights' list.
    Returns: [{title, url, image}]
    """
    html = http_get(url)
    items = []
    for m in re.finditer(
        r'<div class="news-section">\s*<a href="([^"]+)">[\s\S]*?src="([^"]+)"[^>]*>[\s\S]*?<p class="txt-white font-weight-bold">([^<]+)</p>',
        html,
        re.IGNORECASE
    ):
        href = _abs(m.group(1))
        img = _abs(m.group(2))
        title = six.ensure_text(m.group(3), encoding='utf-8', errors='ignore').strip()
        items.append({'title': title, 'url': href, 'image': img})
    return items


