# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import re
import requests
import six

from six.moves.urllib.parse import quote_plus, urlparse


UA = 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36'
SESSION = requests.Session()


def _http_get(url, referer=None):
    headers = {'User-Agent': UA}
    if referer:
        headers['Referer'] = referer
    r = SESSION.get(url, headers=headers, timeout=12, allow_redirects=True, verify=False)
    r.raise_for_status()
    return six.ensure_text(r.text, encoding='utf-8', errors='ignore')


def _absolutize(base, src):
    if not src:
        return src
    src = src.strip()
    if src.startswith('http://') or src.startswith('https://'):
        return src
    if src.startswith('//'):
        p = urlparse(base)
        return p.scheme + ':' + src
    if src.startswith('/'):
        p = urlparse(base)
        return p.scheme + '://' + p.netloc + src
    return src


def _extract_media_url(html):
    # Try common patterns first
    m = re.search(r'var\s+playbackURL\s*=\s*["\']([^"\']+)["\']', html, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    m = re.search(r'(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)', html, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    m = re.search(r'(https?://[^\s"\'<>]+\.mpd[^\s"\'<>]*)', html, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    m = re.search(r'source[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    return None


def resolve(url, referer=None, max_hops=4):
    """
    Generic resolver for aggregator links.
    - Follows iframe chains
    - Extracts .m3u8/.mpd and common playbackURL variables
    - Returns Kodi pipe-header URL when we can attach Referer/UA
    """
    if not url:
        return url

    # If already in Kodi pipe format, keep as-is
    if '|' in url and ('User-Agent=' in url or 'Referer=' in url):
        return url

    current = url
    ref = referer or url

    # Direct media
    if any(x in current for x in ('.m3u8', '.mpd', '.mp4')):
        return current + '|Referer=' + quote_plus(ref) + '&User-Agent=' + quote_plus(UA)

    for _ in range(max_hops):
        html = _http_get(current, referer=ref)
        media = _extract_media_url(html)
        if media:
            media = _absolutize(current, media)
            if any(x in media for x in ('.m3u8', '.mpd', '.mp4')):
                return media + '|Referer=' + quote_plus(current) + '&User-Agent=' + quote_plus(UA)
            # If extracted is a page, follow one more hop
            ref = current
            current = media
            continue

        # iframe fallback
        m_if = re.search(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE)
        if not m_if:
            break
        nxt = _absolutize(current, m_if.group(1))
        ref = current
        current = nxt

        if any(x in current for x in ('.m3u8', '.mpd', '.mp4')):
            return current + '|Referer=' + quote_plus(ref) + '&User-Agent=' + quote_plus(UA)

    # Give up: return last URL
    return current


